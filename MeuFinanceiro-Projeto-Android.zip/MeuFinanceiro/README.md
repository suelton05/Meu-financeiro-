# Meu Financeiro — projeto Android inicial

Este é um projeto Android nativo em Kotlin. Ele inclui:
- Cadastro de pessoas (nome, telefone e endereço)
- Cadastro de empréstimos com taxa mensal e parcelas pela fórmula Price
- Registro de pagamentos parciais com distribuição manual entre principal, juros e encargos
- Armazenamento local no aparelho
- Resumo simples de saldos
- Verificação diária de vencimento para notificar parcelas com vencimento amanhã

## Gerar APK pelo celular usando GitHub

1. Baixe e extraia este ZIP.
2. Crie uma conta em https://github.com e um repositório novo chamado `MeuFinanceiro`.
3. Pelo navegador do celular, abra o repositório e envie todos os arquivos e pastas extraídos, mantendo a estrutura.
4. Abra a aba **Actions** do repositório.
5. Se necessário, autorize a execução de workflows.
6. Aguarde o workflow **Build Meu Financeiro APK** terminar com status verde.
7. Abra a execução concluída, vá em **Artifacts** e baixe `MeuFinanceiro-debug`.
8. Extraia o ZIP do artifact e instale `app-debug.apk` no Android.

## Observações importantes

- Esta é uma primeira versão funcional/MVP, não uma versão final auditada.
- O saldo é uma estimativa simplificada; a agenda de parcelas e a apropriação de pagamentos precisam ser refinadas antes de uso comercial.
- O lembrete diário usa WorkManager, que pode executar em horário aproximado, não em minuto exato. No Android 13 ou superior, permita notificações.
- Os dados ficam no armazenamento privado do app. Desinstalar o app pode apagar os dados; faça backup antes.
- O projeto não inclui assinatura de lançamento para publicação na Play Store.
- Confira as regras legais aplicáveis a juros, multas e encargos antes de utilizar em operações reais.
