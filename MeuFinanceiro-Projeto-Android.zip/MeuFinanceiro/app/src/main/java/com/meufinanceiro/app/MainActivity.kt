package com.meufinanceiro.app

import android.Manifest
import android.app.DatePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.app.Activity
import androidx.core.app.ActivityCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.Calendar
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.math.pow

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private val pad = 16

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        scheduleReminders()
        buildScreen()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
        }
    }

    private fun scheduleReminders() {
        val request = PeriodicWorkRequestBuilder<ReminderWorker>(24, TimeUnit.HOURS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "lembretes_vencimento", ExistingPeriodicWorkPolicy.UPDATE, request
        )
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, 32)
        }
        scroll.addView(content)
        setContentView(scroll)
        titleText("Meu Financeiro")
        text("Controle de clientes, empréstimos e recebimentos.")
        dashboard()
        section("Cadastrar pessoa")
        val name = field("Nome completo")
        val phone = field("Telefone")
        val address = field("Endereço completo")
        button("Salvar pessoa") {
            if (name.text.isBlank()) { toast("Informe o nome."); return@button }
            val arr = Storage.clients(this)
            arr.put(JSONObject().apply {
                put("id", UUID.randomUUID().toString())
                put("name", name.text.toString())
                put("phone", phone.text.toString())
                put("address", address.text.toString())
            })
            Storage.saveClients(this, arr)
            name.text.clear(); phone.text.clear(); address.text.clear()
            toast("Pessoa cadastrada!")
            refresh()
        }
        section("Cadastrar empréstimo")
        val clientSpinner = Spinner(this)
        content.addView(clientSpinner)
        val principal = field("Valor emprestado (R$)", "1000")
        val rate = field("Juros ao mês (%)", "5")
        val count = field("Quantidade de parcelas", "5")
        val due = field("Primeiro vencimento (AAAA-MM-DD)", LocalDate.now().plusDays(30).toString())
        button("Escolher data") {
            val c = Calendar.getInstance()
            DatePickerDialog(this, { _, y, m, d ->
                due.setText(String.format("%04d-%02d-%02d", y, m + 1, d))
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
        }
        button("Salvar empréstimo") {
            val clients = Storage.clients(this)
            val index = clientSpinner.selectedItemPosition
            if (clients.length() == 0 || index !in 0 until clients.length()) {
                toast("Cadastre uma pessoa primeiro."); return@button
            }
            val pv = principal.text.toString().replace(",", ".").toDoubleOrNull()
            val r = rate.text.toString().replace(",", ".").toDoubleOrNull()
            val n = count.text.toString().toIntOrNull()
            if (pv == null || r == null || n == null || pv <= 0 || n <= 0 || r < 0) {
                toast("Confira valor, taxa e parcelas."); return@button
            }
            val monthly = r / 100.0
            val payment = if (monthly == 0.0) pv / n else
                pv * monthly / (1.0 - (1.0 + monthly).pow(-n))
            val client = clients.getJSONObject(index)
            val loans = Storage.loans(this)
            loans.put(JSONObject().apply {
                put("id", UUID.randomUUID().toString())
                put("clientId", client.optString("id"))
                put("clientName", client.optString("name"))
                put("principal", pv)
                put("rate", r)
                put("installments", n)
                put("installment", payment)
                put("dueDate", due.text.toString())
                put("payments", JSONArray())
            })
            Storage.saveLoans(this, loans)
            toast("Empréstimo salvo. Parcela: ${Storage.money(payment)}")
            refresh()
        }
        section("Registrar pagamento parcial ou total")
        val loanSpinner = Spinner(this)
        content.addView(loanSpinner)
        val pPrincipal = field("Valor destinado ao principal (R$)", "0")
        val pInterest = field("Valor destinado aos juros (R$)", "0")
        val pCharges = field("Valor destinado a encargos (R$)", "0")
        button("Registrar pagamento") {
            val loans = Storage.loans(this)
            val idx = loanSpinner.selectedItemPosition
            if (idx !in 0 until loans.length()) { toast("Cadastre um empréstimo primeiro."); return@button }
            val vp = parseMoney(pPrincipal); val vi = parseMoney(pInterest); val vc = parseMoney(pCharges)
            if (vp < 0 || vi < 0 || vc < 0 || vp + vi + vc <= 0) {
                toast("Informe valores válidos."); return@button
            }
            val loan = loans.getJSONObject(idx)
            val payments = loan.optJSONArray("payments") ?: JSONArray()
            payments.put(JSONObject().apply {
                put("date", LocalDate.now().toString())
                put("principal", vp); put("interest", vi); put("charges", vc)
            })
            loan.put("payments", payments)
            loans.put(idx, loan)
            Storage.saveLoans(this, loans)
            pPrincipal.setText("0"); pInterest.setText("0"); pCharges.setText("0")
            toast("Pagamento registrado.")
            refresh()
        }
        section("Resumo e empréstimos")
        refreshSpinners(clientSpinner, loanSpinner)
        listLoans()
    }

    private fun refresh() {
        // Rebuilds the screen so lists and selectors reflect saved records.
        buildScreen()
    }

    private fun refreshSpinners(clientSpinner: Spinner, loanSpinner: Spinner) {
        val clients = Storage.clients(this)
        val clientNames = (0 until clients.length()).map { clients.getJSONObject(it).optString("name") }
        clientSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, clientNames)
        val loans = Storage.loans(this)
        val loanNames = (0 until loans.length()).map {
            val l = loans.getJSONObject(it)
            "${l.optString("clientName")} — ${Storage.money(l.optDouble("installment"))}/parcela"
        }
        loanSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, loanNames)
    }

    private fun listLoans() {
        val loans = Storage.loans(this)
        if (loans.length() == 0) { text("Nenhum empréstimo cadastrado."); return }
        for (i in 0 until loans.length()) {
            val l = loans.getJSONObject(i)
            val payments = l.optJSONArray("payments") ?: JSONArray()
            val due = l.optString("dueDate")
            val balance = Storage.loanBalance(l)
            text("${l.optString("clientName")}\nParcela: ${Storage.money(l.optDouble("installment"))} × ${l.optInt("installments")}\nVencimento inicial: $due\nPagamentos registrados: ${payments.length()}\nSaldo estimado: ${Storage.money(balance)}")
            divider()
        }
    }

    private fun dashboard() {
        val loans = Storage.loans(this)
        var total = 0.0
        var late = 0
        var tomorrow = 0
        val today = LocalDate.now()
        for (i in 0 until loans.length()) {
            val l = loans.getJSONObject(i)
            total += Storage.loanBalance(l)
            val date = runCatching { LocalDate.parse(l.optString("dueDate")) }.getOrNull()
            if (date != null && Storage.loanBalance(l) > 0) {
                if (date.isBefore(today)) late++
                if (date == today.plusDays(1)) tomorrow++
            }
        }
        text("A receber (saldo estimado): ${Storage.money(total)}\nEmpréstimos com vencimento inicial atrasado: $late\nVencimentos amanhã: $tomorrow")
    }

    private fun titleText(value: String) {
        val t = TextView(this).apply { text = value; textSize = 26f; setTextColor(0xFF124B3D.toInt()); setPadding(0, 0, 0, 8) }
        content.addView(t)
    }
    private fun section(value: String) {
        val t = TextView(this).apply { text = value; textSize = 19f; setTextColor(0xFF176B55.toInt()); setPadding(0, 20, 0, 8) }
        content.addView(t)
    }
    private fun text(value: String) {
        val t = TextView(this).apply { text = value; textSize = 15f; setTextColor(0xFF222222.toInt()); setPadding(0, 6, 0, 8) }
        content.addView(t)
    }
    private fun field(hintText: String, value: String = ""): EditText {
        val e = EditText(this).apply {
            hint = hintText
            setSingleLine(true)
            setText(value)
            textSize = 16f
        }
        content.addView(e, ViewGroup.LayoutParams(-1, -2))
        return e
    }
    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply { text = label; isAllCaps = false; setOnClickListener { action() } }
        content.addView(b, ViewGroup.LayoutParams(-1, -2))
    }
    private fun divider() {
        val v = TextView(this).apply { text = "────────────────────────"; setTextColor(0xFFBBBBBB.toInt()) }
        content.addView(v)
    }
    private fun parseMoney(e: EditText): Double =
        e.text.toString().replace(",", ".").toDoubleOrNull() ?: -1.0
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
