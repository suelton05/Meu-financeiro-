package com.meufinanceiro.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray
import java.time.LocalDate

class ReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val tomorrow = LocalDate.now().plusDays(1).toString()
        val loans = Storage.loans(applicationContext)
        val due = mutableListOf<String>()
        for (i in 0 until loans.length()) {
            val loan = loans.optJSONObject(i) ?: continue
            if (loan.optString("dueDate") == tomorrow && Storage.loanBalance(loan) > 0.0) {
                due.add(loan.optString("clientName") + " — " + Storage.money(loan.optDouble("installment")))
            }
        }
        if (due.isNotEmpty()) {
            val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channelId = "vencimentos"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                manager.createNotificationChannel(NotificationChannel(channelId, "Vencimentos", NotificationManager.IMPORTANCE_DEFAULT))
            }
            val notification = NotificationCompat.Builder(applicationContext, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Parcelas vencem amanhã")
                .setContentText(due.take(3).joinToString("; "))
                .setStyle(NotificationCompat.BigTextStyle().bigText(due.joinToString("\n")))
                .setAutoCancel(true)
                .build()
            manager.notify(1001, notification)
        }
        return Result.success()
    }
}
