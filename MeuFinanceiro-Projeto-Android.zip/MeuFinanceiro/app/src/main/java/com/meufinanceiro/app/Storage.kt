package com.meufinanceiro.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Storage {
    private const val PREFS = "meu_financeiro"
    private const val CLIENTS = "clients"
    private const val LOANS = "loans"

    fun clients(context: Context): JSONArray =
        JSONArray(context.getSharedPreferences(PREFS, 0).getString(CLIENTS, "[]"))

    fun loans(context: Context): JSONArray =
        JSONArray(context.getSharedPreferences(PREFS, 0).getString(LOANS, "[]"))

    fun saveClients(context: Context, data: JSONArray) {
        context.getSharedPreferences(PREFS, 0).edit().putString(CLIENTS, data.toString()).apply()
    }

    fun saveLoans(context: Context, data: JSONArray) {
        context.getSharedPreferences(PREFS, 0).edit().putString(LOANS, data.toString()).apply()
    }

    fun money(value: Double): String = "R$ " + String.format("%.2f", value)

    fun loanBalance(loan: JSONObject): Double {
        val principal = loan.optDouble("principal", 0.0)
        val totalInterest = loan.optDouble("installment", 0.0) *
            loan.optInt("installments", 1) - principal
        val payments = loan.optJSONArray("payments") ?: JSONArray()
        var paid = 0.0
        for (i in 0 until payments.length()) {
            val p = payments.getJSONObject(i)
            paid += p.optDouble("principal", 0.0) +
                    p.optDouble("interest", 0.0) +
                    p.optDouble("charges", 0.0)
        }
        return (principal + totalInterest - paid).coerceAtLeast(0.0)
    }
}
